"""Preprocessing module for InvoiceParser"""
