"""App module for InvoiceParser"""
