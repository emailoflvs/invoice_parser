"""InvoiceParser - AI-powered invoice parser"""
__version__ = "0.1.0"
