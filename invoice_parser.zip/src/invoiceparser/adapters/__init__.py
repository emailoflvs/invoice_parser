"""Adapters module for InvoiceParser"""
