"""Infra module for InvoiceParser"""
