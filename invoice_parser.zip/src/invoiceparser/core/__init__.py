"""Core module for InvoiceParser"""
