"""Utils module for InvoiceParser"""
